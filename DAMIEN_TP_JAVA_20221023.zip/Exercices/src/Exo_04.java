
public class Exo_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// déjà corrigé, correction à regarder
	}

}
