
public class Exo_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// déjà corrigé, correction à regarder
	}

}
