
public class Exo_10bis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
