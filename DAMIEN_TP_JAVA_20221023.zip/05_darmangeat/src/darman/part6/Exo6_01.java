package darman.part6;

public class Exo6_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] monTab = new int[7];

		for (int i = 0; i <= 6; i++) {
			monTab[i] = 0;
			System.out.println("monTab[" + i + "] = " + monTab[i]);
		}

	}

}
