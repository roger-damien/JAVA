package darman.part2;

public class Exo2_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int val = 231;
		int Double = val * 2;
		System.out.println("Ecrire val : " + val + " Ecrire Double : " + Double);
	}
}
// On verra apparaître à l’écran 231, puis 462 (qui vaut 231 * 2)