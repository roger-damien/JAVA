package darman.part1;

public class Exo1_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 3;
		int b = 10;
		int c = a + b;
		b += a;
		a = c;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b + " et c :  " + c);

	}

}
