package darman.part6;

public class Exo6_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nb = new int[6];
		int i;

		for (i = 0; i <= 5; i++) {
			nb[i] = i * i;
			System.out.println(nb[i]);

		}

	}

}

//
//Tableau Nb[5] en Entier
//Variable i en Entier
//Début
//Pour i ← 0 à 5
//  Nb[i] ← i * i
//i suivant
//Pour i ← 0 à 5
//  Ecrire Nb[i]
//i suivant
//Fin