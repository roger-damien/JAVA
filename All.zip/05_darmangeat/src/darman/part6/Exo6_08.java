package darman.part6;

public class Exo6_08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

//
//Variables Nb, Nbpos, Nbneg en Numérique
//Tableau T[] en Numérique
//Debut
//Ecrire "Entrez le nombre de valeurs :"
//Lire Nb
//Redim T[Nb-1]
//Nbpos ← 0
//Nbneg ← 0
//Pour i ← 0 à Nb - 1
//  Ecrire "Entrez le nombre n° ", i + 1
//  Lire T[i]
//  Si T[i] > 0 alors
//    Nbpos ← Nbpos + 1
//  Sinon
//    Nbneg ← Nbneg + 1
//  Finsi
//i Suivant
//Ecrire "Nombre de valeurs positives : ", Nbpos
//Ecrire "Nombre de valeurs négatives : ", Nbneg
//Fin