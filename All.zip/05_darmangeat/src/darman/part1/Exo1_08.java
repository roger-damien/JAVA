package darman.part1;

public class Exo1_08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String a = "423";
		String b = "12";
		String c = a + b;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b + " et c :  " + c);
	}

}
