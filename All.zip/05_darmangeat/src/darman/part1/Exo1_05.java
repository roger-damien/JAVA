package darman.part1;

public class Exo1_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 5;
		int b = 2;
		a = b;
		b = a;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b);
	}

}
