package darman.part1;

public class Exo1_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 2;
		int b = 3;
		int c = b;
		b = a;
		a = c;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b);

	}

}
