package exercice_07;

public class item4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
