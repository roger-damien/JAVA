
public class Exo_3bis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
