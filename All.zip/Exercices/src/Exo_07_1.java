
public class Exo_07_1 {

	public static void main(String[] args) {
		  
		   
		   for (short i = 1; i<= 40000; i++ ) {
			   System.out.println(i);
		   }
			}

}
