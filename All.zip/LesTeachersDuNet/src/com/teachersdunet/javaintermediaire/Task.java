package com.teachersdunet.javaintermediaire;

public class Task {
	// on crée 2 propriétés (ou attributs, caractéristiques ou données) , un string
	// et un boolean
	public String title;
	public String description;
	public boolean completed = false;

	// on crée un constructeur
	public Task(String title, String description) {
		this.title = title;
		this.description = description;
	}

	// on ajoute une méthode
	public void complete() {
		completed = true;
	}

}
