package com.teachersdunet.javaintermediaire;

public class Personne {
	private String nom;// vu que cette variable sera spécifique à un objet, c'est une variable
						// d'instance, puisqu'un objet est une instance d'une classe

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if (age < 15) {
			// System.out.println("Interdit au - de 15 ans");
			throw new IllegalArgumentException("l'age doit etre sup à 15 ans");
		} else {
			this.age = age;
		}
	}

	public static void setNombreTotalDePersonnes(int nombreTotalDePersonnes) {
		Personne.nombreTotalDePersonnes = nombreTotalDePersonnes;
	}

	private String prenom;
	private int age;

	public static int nombreTotalDePersonnes = 0;// variable statiques ou variable de classe, donc tous les objets vont
													// partager cette même valeur

	public Personne(String nom, String prenom, int age) {
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		nombreTotalDePersonnes++;
	}

	public static int getNombreTotalDePersonnes() {// methode statiques ou méthode de classe peut etre appeler sans
													// créer d'instance. C'est par exemple le cas avec JoptionPane
		return nombreTotalDePersonnes;
	}

}
