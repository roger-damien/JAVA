package com.teachersdunet.javaintermediaire;

public class TaskTest {

	public static void main(String[] args) {
		Task tache1 = new Task("titre1", "description1");
		Task tache2 = new Task("titre2", "description2");
		Task tache3 = new Task("titre3", "description3");

		System.out.println(tache1.title + " " + tache1.description);

		tache2.complete();

		System.out.println(tache2.completed);

	}

}
