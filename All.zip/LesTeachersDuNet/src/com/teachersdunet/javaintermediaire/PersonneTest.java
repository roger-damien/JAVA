package com.teachersdunet.javaintermediaire;

public class PersonneTest {

	public static void main(String[] args) {
		Personne p1 = new Personne("Roger", "Damien", 13);
		Personne p2 = new Personne("Anne", "Damien", 36);
		Personne p3 = new Personne("Gwendoline", "Damien", 38);
		try {
			p1.setAge(11);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}

		System.out.println("ok, je m'affiche");

	}

}
