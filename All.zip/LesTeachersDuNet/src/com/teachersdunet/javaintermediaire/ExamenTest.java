package com.teachersdunet.javaintermediaire;

import java.util.Scanner;

public class ExamenTest {

	public static void main(String[] args) {

		Examen monObjet = new Examen();// on instancie la classe en créant un nouvel objet

		System.out.println("Quel est le message ?");
		Scanner sc = new Scanner(System.in);
		String message = sc.nextLine(); // on enregistre les paramètres de la méthode

		monObjet.afficherMessage(message);
		sc.close();
	}

}
