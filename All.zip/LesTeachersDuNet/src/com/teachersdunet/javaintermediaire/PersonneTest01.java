package com.teachersdunet.javaintermediaire;

public class PersonneTest01 {

	public static void main(String[] args) {
		Personne01 p1 = new Personne01("Roger", 58);
		System.out.println(p1.nom + " " + p1.age);
	}

}
