package com.teachersdunet.javaintermediaire;

public class Personne01 {
	public String nom;
	public int age;

	// public Personne(String n, int age) {
	public Personne01(String nom, int age) {
		// this.nom = n; // this fait référence à l'objet courant (par ex p1.nom dans la
		// class
		// PersonneTest
		this.nom = nom;// this fait référence à l'objet courant
		this.age = age;
	}

}
