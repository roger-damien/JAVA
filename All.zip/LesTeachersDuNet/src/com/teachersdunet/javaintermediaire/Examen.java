package com.teachersdunet.javaintermediaire;

public class Examen {
	public void afficherMessage(String matiere) {
		System.out.printf("Bienvenue à cet examen de la matiere %s", matiere);
	}

}
