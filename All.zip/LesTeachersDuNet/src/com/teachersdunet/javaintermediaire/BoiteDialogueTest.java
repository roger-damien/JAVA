package com.teachersdunet.javaintermediaire;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class BoiteDialogueTest {

	public static void main(String[] args) {

		String snbr1 = JOptionPane.showInputDialog("Entrez le nombre 1");
		int nbr1 = Integer.parseInt(snbr1);

		// on peut simplifier
		int nbr2 = Integer.parseInt(JOptionPane.showInputDialog("Entrez le nombre 2"));

		String resultat = String.format("La somme de nbr1 %d et nbr2 %d est %d ", nbr1, nbr2, (nbr1 + nbr2));

		JOptionPane.showMessageDialog(null, "Le résultat est " + resultat);
	}

	Scanner clavier = new Scanner(System.in);

}
