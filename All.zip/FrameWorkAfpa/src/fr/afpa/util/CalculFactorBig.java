package fr.afpa.util;

import static fr.afpa.math.Math.factorielleBig;

import java.math.BigDecimal;
import java.util.Scanner;

public class CalculFactorBig {

	static Scanner clavier = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("Ecrivez le nombre dont on veut calculer la factorielle :");
		BigDecimal bnbr = clavier.nextBigDecimal();
		BigDecimal var = factorielleBig(bnbr);
		System.out.println(var);

	}

}
