package fr.afpa.util;

import java.util.Scanner;

import fr.afpa.math.MathBean;

public class CalculFactor2 {

	public static void main(String[] args) {

		Scanner clavier = new Scanner((System.in));

		MathBean m = new MathBean();
		System.out.println("Saisissez la valeur :");
		int n = clavier.nextInt();
		System.out.println(m.factoriel(n));

		clavier.close();

	}

}
