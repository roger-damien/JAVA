package fr.afpa.tool;

import java.time.LocalDate;

public class UtilitaireBookstore {

//	public static boolean isPretEnRetard(LocalDate dateEmpruntEffective, LocalDate maintenant, int dureeMaxPret) {
//		boolean verif = false;	
//
//		LocalDate dateActuelle = LocalDate.now();				
//		LocalDate dateMax = dateActuelle.plusDays(15);
//		
//		return verif;
//	}

	public static void main(String[] args) {

		LocalDate dateEmpruntEffective = "2022-10-15";
		LocalDate maintenant = LocalDate.now();
		int dureeMaxPret = 15;
		LocalDate dateMax = maintenant.plusDays(dureeMaxPret);

		System.out.println(maintenant);
		System.out.println(dateMax);

	}

}
