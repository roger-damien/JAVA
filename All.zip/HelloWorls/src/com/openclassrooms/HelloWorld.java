package com.openclassrooms;

public class HelloWorld {

	public static void main(String[] args) {
		int i;
		for (i = 0; i < 5; i++) {
			System.out.println("Bienvenue dans Eclipse !");
		}

		System.out.println("C'est la fin !");
		
		var z = 1;
		var p = "testvar2";
		System.out.println(z + p);
	}

	public int sommeNombres(int num1, int num2) {
		return num1 + num2;
		
		
		
	}
	
}
