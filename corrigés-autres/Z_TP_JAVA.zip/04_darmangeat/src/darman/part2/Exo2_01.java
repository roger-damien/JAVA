package darman.part2;

public class Exo2_01 {

	public static void main(String[] args) {
		short val=231,carre=(short)(val*2);
		System.out.println(val);
		System.out.println(carre);
		// Ecris 231 puis 462
	}
	
}
