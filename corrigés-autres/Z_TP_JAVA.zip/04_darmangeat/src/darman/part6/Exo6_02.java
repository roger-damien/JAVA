package darman.part6;

import java.util.Arrays;

public class Exo6_02 {

	public static void main(String[] args) {
		char[] tab={'a','e','i','o','u','y'};
		System.out.printf("tab=%s",Arrays.toString(tab));
	}

}
