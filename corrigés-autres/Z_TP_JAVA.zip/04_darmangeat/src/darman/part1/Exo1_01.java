package darman.part1;

public class Exo1_01 {
	
	public static void main(String[] args){
		byte a=1,b;
		b=(byte)(a+3);
		a=3;
		
		// a=3, b=4
		// Controle
		System.out.println("a="+a+", b="+b);
	}
	
}
