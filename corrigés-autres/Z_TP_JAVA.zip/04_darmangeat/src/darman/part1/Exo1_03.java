package darman.part1;

public class Exo1_03 {
	
	public static void main (String[] args){
		byte a=5,b;
		b=(byte)(a+4);
		a++;
		b=(byte)(a-4);
		
		// a=6, b=2
		// Controle
		System.out.println("a="+a+", b="+b);
	}
	
}
