package darman.part1;

public class Exo1_08 {

	public static void main(String[] args) {
		String a="423",b="12",c;
		// On ne peut pas additionner des caractères
		System.out.println("On ne peut pas additionner des caractères");
	}

}
