package darman.part1;

public class Exo1_09 {

	public static void main(String[] args) {
		String a="423",b="12",c;
		c=a+b;
		
		// L'algorithme concatène a et b dans c, c: 42312
		// Controle
		System.out.println("c="+c);
	}

}
