package Darmangeat.Part8;

import java.util.Arrays;

public class Ex8_1 {

    public static void main(String[] args) {

        int[][] tableau = new int[5][12];
    }
}
