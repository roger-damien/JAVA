package Darmangeat.Part1;

public class Ex1_9 {

    public static void main(String[] args) {

        String a = "423";
        String b = "12";
        String c = a + b;

        System.out.println("c = " + c);

    }

    //42312
}
