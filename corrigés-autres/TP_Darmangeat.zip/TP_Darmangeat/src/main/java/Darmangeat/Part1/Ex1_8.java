package Darmangeat.Part1;

public class Ex1_8 {

    public static void main(String[] args) {


    }

    // erreur, on n'additionne pas des caractères

}
