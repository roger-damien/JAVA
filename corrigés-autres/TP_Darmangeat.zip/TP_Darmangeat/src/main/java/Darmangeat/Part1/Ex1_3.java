package Darmangeat.Part1;

public class Ex1_3 {

    public static void main(String[] args) {

        int a = 5;
        int b = a + 4;
        a = a + 1;
        b = a - 4;

        System.out.println("a = " + a);
        System.out.println("b = " + b);

    }

    // a = 6
    // b = 2

}
