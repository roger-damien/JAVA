package Darmangeat.Part1;

public class Ex1_7 {

    public static void main(String[] args) {

        int a = 1;
        int b = 2;
        int c = 3;
        int d;

        d = c;
        c = b;
        b = a;
        a = d;

        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("c = " + c);

    }


    //Début
    //D ← C
    //C ← B
    //B ← A
    //A ← D
    //Fin

}
