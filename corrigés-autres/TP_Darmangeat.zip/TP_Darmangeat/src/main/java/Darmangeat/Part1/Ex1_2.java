package Darmangeat.Part1;

public class Ex1_2 {


    public static void main(String[] args) {

        int a = 5;
        int b = 3;
        int c = a + b;
        a = 2;
        c = b - a;

        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("c = " + c);



    }





    //a = 2
    //b = 3
    //c = 1

}
