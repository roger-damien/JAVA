package Darmangeat.Part1;

public class Ex1_1 {
    public static void main(String[] args) {

        int a = 1;
        int b = a + 3;
        a = 3;

        System.out.println("a = " + a);
        System.out.println("b = " + b);


        // a = 3
        // b = 4


    }
}