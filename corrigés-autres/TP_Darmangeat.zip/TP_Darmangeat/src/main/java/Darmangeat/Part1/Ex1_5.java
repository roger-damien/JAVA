package Darmangeat.Part1;

public class Ex1_5 {

    public static void main(String[] args) {

        int a = 5;
        int b = 2;
        a = b;
        b = a;

        System.out.println("a = " + a);
        System.out.println("b = " + b);

    }

    //a = 2
    //b = 2

}
