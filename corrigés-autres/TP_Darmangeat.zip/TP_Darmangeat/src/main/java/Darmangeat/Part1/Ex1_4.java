package Darmangeat.Part1;

public class Ex1_4 {


    public static void main(String[] args) {

        int a = 3;
        int b = 10;
        int c = a + b;
        b = a + b;
        a = c;

        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("b = " + b);

    }

    // a = 13
    // b = 13
    // c = 13

}
