package Darmangeat.Part1;

public class Ex1_6 {

    public static void main(String[] args) {

        int a = 1;
        int b = 2;
        int c;

        c = a;
        a = b;
        b = c;

        System.out.println("a = " + a);
        System.out.println("b = " + b);

    }

    //Début
    //C ← A
    //A ← B
    //B ← C
    //Fin

}
