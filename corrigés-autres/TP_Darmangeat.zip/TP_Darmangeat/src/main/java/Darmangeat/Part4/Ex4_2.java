package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_2 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        System.out.println("Entrer l'heure puis les minutes");
        int heure = scanner.nextInt();
        int minutes = scanner.nextInt();

        if(minutes+1 >= 60){
            System.out.println("Dans une minute, il sera " + (heure+1) + " heure(s)");
        } else {
            System.out.println("Dans une minute, il sera " + heure + " heure(s) " + (minutes+1));
        }



    }

}
