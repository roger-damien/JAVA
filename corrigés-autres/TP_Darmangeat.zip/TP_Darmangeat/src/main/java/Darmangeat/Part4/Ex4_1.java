package Darmangeat.Part4;


import java.util.Scanner;

public class Ex4_1 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Entrer deux chiffres puis une chaîne de caractères \"OK\"");
        double tutu = scanner.nextDouble();
        double toto = scanner.nextDouble();
        scanner.nextLine();
        String tata = scanner.nextLine().toUpperCase();

        if (tutu > (toto + 4) || tata.equals("OK")){
            tutu = tutu + 1;
        } else {
            tutu = tutu - 1;
        }

        System.out.println("tutu : " + tutu);

    }


}
