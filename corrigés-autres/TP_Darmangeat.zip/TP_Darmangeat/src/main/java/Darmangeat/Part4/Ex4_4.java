package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_4 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Entrer le nombre de photocopie.s que vous voulez faire : ");
        int nombreDePhotocopie = scanner.nextInt();

        double coutFinal = 0;
        for (int i = 1 ; i <= nombreDePhotocopie ; i++){
            if (i >= 1 && i <= 10){
                coutFinal = coutFinal + 0.10;
//                System.out.println("+0.10");
            }
            if (i >= 11 && i <= 30){
                coutFinal = coutFinal + 0.09;
//                System.out.println("+0.09");
            }
            if (i >= 30){
                coutFinal = coutFinal + 0.08;
//                System.out.println("+0.08");

            }
        }

        System.out.println("Coût total : " + coutFinal + "€");
    }
}
