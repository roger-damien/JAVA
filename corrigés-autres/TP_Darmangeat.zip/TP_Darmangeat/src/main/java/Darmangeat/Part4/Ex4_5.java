package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_5 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Êtes-vous un homme ou une femme? (h/f)");
        boolean unHomme = scanner.nextLine().equals("h");

        System.out.println("Quel age avez-vous?");
        int age = scanner.nextInt();

        boolean payerImpots = unHomme && age > 20 || !unHomme && age >= 18 && age <= 35;

        if(payerImpots){
            System.out.println("Imposable :(");
        } else {
            System.out.println("Non imposable :D");
        }
    }
}
