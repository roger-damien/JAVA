package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Entrer l'heure puis les minutes puis les secondes");

        int heure = scanner.nextInt();
        int minutes = scanner.nextInt();
        int secondes = scanner.nextInt();
        int secondesPlusUn = secondes + 1;

        if (secondesPlusUn >= 60){
            secondesPlusUn = 0;
            minutes++;
        }
        if (minutes >= 60){
            minutes = 0;
            heure++;
        }


        System.out.println("Dans une seconde, il sera "
                + heure + " heures(s), "
                + minutes + " minute(s) et "
                + (secondesPlusUn) + " seconde(s)");



    }

}
