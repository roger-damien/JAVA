package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_7 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer votre âge :");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Depuis combien d'années avez-vous le permis?");
        int anneesDePermis = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Avez-vous déjà été responsable d'un accident? (o/n)");
        boolean aDejaEuUnAccidentResponsable = scanner.nextLine().equals("o");

        System.out.println("Depuis combien de temps êtes-vous client?");
        boolean estClientDepuisPlusDeCinqAns = scanner.nextInt() >= 5;

        int nombrePoints = 0;
        nombrePoints = age >= 25? nombrePoints+1 : nombrePoints;
        nombrePoints = anneesDePermis >= 2? nombrePoints+1 : nombrePoints;
        nombrePoints = !aDejaEuUnAccidentResponsable? nombrePoints+1 : nombrePoints;
        nombrePoints = estClientDepuisPlusDeCinqAns? nombrePoints+1 : nombrePoints;

        String pastille = "";

        switch (nombrePoints){
            case 4:
                pastille = "Pastille blue";
                break;
            case 3:
                pastille = "Pastille verte";
                break;
            case 2:
                pastille = "Pastille orange";
                break;
            case 1:
                pastille = "Pastille rouge";
                break;
            case 0:
                pastille = "Mince, refusé.";
                break;
            default:
                pastille = "Hors grille, merci de contacter un opérateur";
        }

        System.out.println(pastille);
    }
}
