package Darmangeat.Part4;

import java.util.Date;
import java.util.Scanner;

public class Ex4_8 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrez le jour, puis le numéro du mois, puis l'année complète(AAAA)");

        int jour = scanner.nextInt();
        scanner.nextLine();
        int mois = scanner.nextInt();
        scanner.nextLine();
        int annee = scanner.nextInt();
        scanner.nextLine();

        int jourDansLeMois;
        if (mois == 1 || mois == 3 || mois == 5 || mois == 7 || mois == 8 || mois == 9 | mois == 11){
            jourDansLeMois = 31;
        }else {
            jourDansLeMois = 30;
        }

        if (mois == 2){
            if(annee % 4 == 0){
                jourDansLeMois = 29;
            } else {
                jourDansLeMois = 28;
            }
        }

        if (jour <= jourDansLeMois && mois <= 12)
        {
            System.out.println("La date " + jour + "/"+ mois + "/" + annee + " est valide");
        } else {
            System.out.println("problème dans la date");
        }
    }
}
