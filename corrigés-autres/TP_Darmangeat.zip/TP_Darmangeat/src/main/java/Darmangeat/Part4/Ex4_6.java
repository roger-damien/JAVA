package Darmangeat.Part4;

import java.util.Scanner;

public class Ex4_6 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer le score de 4 candidats au premier tour en %:");
        double candidatUn = scanner.nextDouble();
        double candidatDeux = scanner.nextDouble();
        double candidatTrois = scanner.nextDouble();
        double candidatQuatre = scanner.nextDouble();

        if (candidatUn > 50){
            System.out.println("Candidat un est élu!");
        } else if (candidatUn <= 50 && candidatUn >= 12.5){
            if (candidatUn > candidatDeux && candidatUn > candidatTrois && candidatUn > candidatQuatre){
                System.out.println("Candidat un est en ballotage favorable " +
                        "(participe au second tour et est arrivé en tête à l'issue du premier tour)");
            } else{
                System.out.println("Candidat un est en ballotage défavorable " +
                        "(participe au second tour et n'est pas arrivé en tête à l'issue du premier tour)");
            }
        } else {
            System.out.println("Candidat un est battu");
        }
    }
}
