package Darmangeat.Part2;

import java.util.Scanner;

public class Ex2_3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Quel est votre prénom?");
        System.out.println("Bonjour " + scanner.nextLine() + "!");
    }
}
