package Darmangeat.Part2;

import java.util.Scanner;

public class Ex2_2 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Trouver le carré de : ");
        int chiffreAMettreAuCarre = scanner.nextInt();
        System.out.println("Le carré de " + chiffreAMettreAuCarre + " = "
                + (chiffreAMettreAuCarre*chiffreAMettreAuCarre));
    }

}
