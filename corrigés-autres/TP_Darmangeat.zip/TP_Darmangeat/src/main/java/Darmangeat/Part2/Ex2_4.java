package Darmangeat.Part2;

import java.util.Scanner;

public class Ex2_4 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer le prix de l'article");
        double prixArticle = scanner.nextDouble();

        System.out.println("Entrer le nombre d'articles");
        int nombreArticles = scanner.nextInt();

        System.out.println("Entrer la tva en %");
        double tvaEnPourcentage = scanner.nextDouble();

        System.out.println("Un article coûte " + prixArticle
        + "\nIl y a " + nombreArticles + "articles"
        + "\nLa tva est de " + tvaEnPourcentage + "%");

        double coutTotal = (nombreArticles*prixArticle)* (1+(tvaEnPourcentage/100));
        System.out.println("Le coût total est de " + coutTotal + "€");




    }


}
