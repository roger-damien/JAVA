package Darmangeat.Part2;

public class Ex2_1 {

    public static void main(String[] args) {

        int val = 231;
        int varDouble = val * 2;

        System.out.println("val = " + val);
        System.out.println("varDouble = " + varDouble);

    }
}
