package Darmangeat.Part6;

public class Ex6_6 {

    public static void main(String[] args) {

        int[] suite = new int[8];

        suite[0] = 1;
        suite[1] = 1;
        System.out.println(suite[0] + "\n" + suite[1]);

        for (int i = 2 ; i <=7 ; i++){
            suite[i] = suite[i-1] + suite[i-2];
            System.out.println(suite[i]);
        }
    }

    // Cet algorithme créer un tableau de 8 entiers : 1, 1, 2, 3, 5, 8, 13, 21
}
