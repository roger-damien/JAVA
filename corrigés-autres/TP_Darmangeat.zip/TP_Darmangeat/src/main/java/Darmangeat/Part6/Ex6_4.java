package Darmangeat.Part6;

public class Ex6_4 {

    public static void main(String[] args) {
        // On écrit à chaque boucle pour éviter d'en refaire une

        int[] nb = new int[6];

        for(int i = 0 ; i <= 5 ; i++){
            nb[i] =  i*i;
            System.out.println(nb[i]);
        }
    }

}
