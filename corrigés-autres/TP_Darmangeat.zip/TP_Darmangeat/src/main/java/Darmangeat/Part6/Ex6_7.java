package Darmangeat.Part6;

import java.util.Scanner;

public class Ex6_7 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        double[] notes = new double[9];

        System.out.println("Entrer les 9 notes :");
        int notesTotal = 0;
        for(int i = 0 ; i <= 8 ; i++){
            notes[i] = scanner.nextDouble();
            scanner.nextLine();
            notesTotal += notes[i];
        }

        double moyenne = (double)notesTotal / notes.length;
        System.out.println("Moyenne : " + moyenne );
    }

}
