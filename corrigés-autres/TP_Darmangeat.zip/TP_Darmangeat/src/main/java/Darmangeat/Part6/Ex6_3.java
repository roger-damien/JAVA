package Darmangeat.Part6;

import java.util.Arrays;
import java.util.Scanner;

public class Ex6_3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        double[] notes = new double[9];

        System.out.println("Entrer les 9 notes :");
        for(int i = 0 ; i <= 8 ; i++){
            notes[i] = scanner.nextDouble();
            scanner.nextLine();
        }

        System.out.println(Arrays.toString(notes));
    }



}
