package Darmangeat.Part6;

import java.util.Arrays;

public class Ex6_10 {

    public static void main(String[] args) {

        int[] tableauUn = {4,8,7,9,1,5,4,6};
        int[] tableauDeux = {7,6,5,2,1,3,7,4};
        int[] tableauSomme = new int[8];

        for (int i = 0 ; i <=(tableauSomme.length-1) ; i++){
            tableauSomme[i] = tableauUn[i]+tableauDeux[i];
        }

        System.out.println(Arrays.toString(tableauSomme));


    }

}
