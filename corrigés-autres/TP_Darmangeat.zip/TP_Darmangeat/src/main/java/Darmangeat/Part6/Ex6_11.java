package Darmangeat.Part6;

public class Ex6_11 {

    public static void main(String[] args) {

        int[] tableauUn = {4,8,7,12};
        int[] tableauDeux = {3,6};

        int somme = 0;
        for(int i = 0 ; i<=(tableauUn.length-1) ; i++){
            for (int k = 0 ; k<= (tableauDeux.length-1) ; k++){
                somme += tableauUn[i]*tableauDeux[k];
            }
        }

        System.out.println(somme);


    }
}
