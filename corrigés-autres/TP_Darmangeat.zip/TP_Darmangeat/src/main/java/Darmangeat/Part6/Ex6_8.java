package Darmangeat.Part6;

import java.util.Scanner;

public class Ex6_8 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Combien de valeur.s dans le tableau?");
        int[] tableau = new int[scanner.nextInt()];

        int compteurNegatif = 0;
        int compteurPositif = 0;
        System.out.println("longueur = " + tableau.length);
        // Pour cet exercice, on considère que 0 est un nombre positif
        for (int i = 0 ; i <= (tableau.length-1) ; i++){
            System.out.println("Rentrer la valeur n°" + (i+1));
            tableau[i] = scanner.nextInt();
            scanner.nextLine();

            if (tableau[i] < 0){
                compteurNegatif++;
            } else {
                compteurPositif++;
            }
        }

        System.out.println("Il y a " + compteurPositif + " nombre.s positif.s et " + compteurNegatif + " nombre.s négatif.s");

    }
}
