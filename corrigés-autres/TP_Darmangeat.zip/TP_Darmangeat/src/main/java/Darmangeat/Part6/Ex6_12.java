package Darmangeat.Part6;

import java.util.Arrays;
import java.util.Scanner;

public class Ex6_12 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Combien de valeur souhaitez-vous?");

        int[] tableau = new int[scanner.nextInt()];
        scanner.nextLine();

        for (int i = 0 ; i <= tableau.length-1 ; i++){
            System.out.println("valeur numéro " + (i+1));
            tableau[i] = scanner.nextInt()+1;
            scanner.nextLine();
        }

        System.out.println(Arrays.toString(tableau));

    }
}
