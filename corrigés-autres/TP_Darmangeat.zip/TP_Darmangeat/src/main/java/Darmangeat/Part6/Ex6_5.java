package Darmangeat.Part6;

public class Ex6_5 {

    public static void main(String[] args) {

        // On écrit à chaque boucle pour éviter d'en refaire une

        int[] n = new int[7];

        n[0] = 1;
        System.out.println(n[0]);

        for (int i = 1 ; i <=6 ; i++){
            n[i] = n[i-1] + 2;
            System.out.println(n[i]);
        }
    }
}
