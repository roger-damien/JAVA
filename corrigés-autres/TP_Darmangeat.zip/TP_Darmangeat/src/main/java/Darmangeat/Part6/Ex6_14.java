package Darmangeat.Part6;

import java.util.Scanner;

public class Ex6_14 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Combien de notes voulez-vous entrer?");
        double[] notes = new double[scanner.nextInt()];

        System.out.println("Entrer les notes :");
        int notesTotal = 0;
        for(int i = 0 ; i <= notes.length-1 ; i++){
            System.out.println("note numéro " + (i+1));
            notes[i] = scanner.nextDouble();
            scanner.nextLine();
            notesTotal += notes[i];
        }

        double moyenne = (double)notesTotal / notes.length;

        int noteAuDessusMoyenne = 0;
        for (Double note : notes){
            if (note > moyenne){
                noteAuDessusMoyenne++;
            }
        }

        System.out.println("La moyenne est de " + moyenne);
        System.out.println("Il y a " + noteAuDessusMoyenne + " notes au dessus de la moyenne");
    }
}
