package Darmangeat.Part6;

public class Ex6_9 {

    public static void main(String[] args) {

        int[] tableau = {1, 8, 9, 7, 8, 6, 40};

        int somme = 0;
        for(Integer valeur : tableau){
            somme += valeur;
        }

        System.out.println("Somme : " + somme);

    }
}
