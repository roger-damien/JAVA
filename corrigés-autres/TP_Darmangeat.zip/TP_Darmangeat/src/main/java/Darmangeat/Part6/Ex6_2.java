package Darmangeat.Part6;

import java.util.Arrays;

public class Ex6_2 {

    public static void main(String[] args) {

        String[] tableauAvecVoyelles = {"a", "e", "i", "o", "u", "y"};
        System.out.println(Arrays.toString(tableauAvecVoyelles));

    }

}
