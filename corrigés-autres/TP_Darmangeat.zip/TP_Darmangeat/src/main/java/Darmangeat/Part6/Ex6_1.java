package Darmangeat.Part6;

import java.util.Arrays;

public class Ex6_1 {


    public static void main(String[] args) {

        int[] septValeursZero = new int[7];
        System.out.println(Arrays.toString(septValeursZero));

    }

}
