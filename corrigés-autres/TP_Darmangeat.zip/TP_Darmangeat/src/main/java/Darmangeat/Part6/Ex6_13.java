package Darmangeat.Part6;

import java.util.Scanner;

public class Ex6_13 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Combien de valeurs souhaitez-vous?");
        int[] tableau = new int[scanner.nextInt()];
        scanner.nextLine();

        for (int i = 0 ; i <= tableau.length-1 ; i++){
            System.out.println("valeur numéro " + (i+1));
            tableau[i] = scanner.nextInt();
            scanner.nextLine();
        }

        int trouverMax = tableau[0];
        int positionMax = 0;
        for (int i = 1 ; i<= tableau.length-1 ; i++){
            if(tableau[i] > trouverMax){
                trouverMax = tableau[i];
                positionMax = i;
            }
        }

        System.out.println("Valeur max : " + trouverMax);
        System.out.println("Position dans tableau : " + positionMax);

    }

}
