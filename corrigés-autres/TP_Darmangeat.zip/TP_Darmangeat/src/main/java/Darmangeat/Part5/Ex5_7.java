package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_7 {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("calculer le factoriel de : ");
        int factoriel = scanner.nextInt();

        for (int i = factoriel-1 ; i > 0 ; i--){
            factoriel *= i;
        }

        System.out.println(factoriel);

    }
}
