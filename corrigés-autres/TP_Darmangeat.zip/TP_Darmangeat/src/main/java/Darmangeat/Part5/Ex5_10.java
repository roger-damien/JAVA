package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_10 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("montant achat : ");
        int prixApayer = scanner.nextInt();
        System.out.println("montant payé");
        int montantAchat = scanner.nextInt();

        int montantRemboursement = prixApayer - montantAchat;

        while (montantRemboursement >= 50)
        {
            System.out.println("rendu 50€");
            montantRemboursement -= 50;
        }
        while (montantRemboursement >= 20)
        {
            System.out.println("rendu 20€");
            montantRemboursement -= 20;
        }
        while (montantRemboursement >= 10)
        {
            System.out.println("rendu 10€");
            montantRemboursement -= 10;
        }
        while (montantRemboursement >= 5)
        {
            System.out.println("rendu 5€");
            montantRemboursement -= 5;
        }
        while (montantRemboursement >= 2)
        {
            System.out.println("rendu 2€");
            montantRemboursement -= 2;
        }
        while (montantRemboursement == 1)
        {
            System.out.println("rendu 1€");
            montantRemboursement -= 1;
        }


    }

}
