package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_4 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer un nombre");

        int nombre = scanner.nextInt() + 1;
        int nombrePlusDix = nombre + 10;

        while (nombre < nombrePlusDix){
            System.out.println(nombre);
            nombre++;
        }

    }

}
