package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_5 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("entrer un nombre :");
        int nombre = scanner.nextInt();

        for (int i = 1 ; i <= 10 ; i++){
            System.out.println(nombre + " x " + i + " = " + (nombre*i));
        }

    }

}
