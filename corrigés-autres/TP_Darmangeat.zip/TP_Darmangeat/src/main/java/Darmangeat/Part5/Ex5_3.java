package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer un nombre");

        int nombre = scanner.nextInt() + 1;
        int nombrePlusDix = nombre + 10;

        for (int i = nombre ; i < nombrePlusDix ; i++){
            System.out.println(i);
        }
    }

}
