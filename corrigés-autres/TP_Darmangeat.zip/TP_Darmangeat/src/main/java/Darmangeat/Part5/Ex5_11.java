package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_11 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Nombre de chevaux partants :");
        int n = scanner.nextInt();

        System.out.println("Nombre de chevaux joués :");
        int p = scanner.nextInt();

        int x = trouverFactoriel(n) / trouverFactoriel((n - p));
        int y = trouverFactoriel(n) / (trouverFactoriel(p) * trouverFactoriel(n-p));

        System.out.println("Dans l'ordre : une chance sur " + x + " de gagner");
        System.out.println("Dans le désordre: une chance sur " + y + " de gagner");


    }

    private static int trouverFactoriel(double chiffre){
        int result = 1;
        for (int i = 1 ; i <= chiffre ; i++){
            result *= i;
        }
        return result;
    }
}
