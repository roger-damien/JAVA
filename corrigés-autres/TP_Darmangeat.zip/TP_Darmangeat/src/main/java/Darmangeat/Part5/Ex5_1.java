package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_1 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {



        while (true){
            System.out.println("Taper un chiffre compris entre un et trois");
            int numero = scanner.nextInt();
            if (numero >= 1 && numero <= 3){
                break;
            }
            scanner.nextLine();
        }
        System.out.println("Merci");

    }

}
