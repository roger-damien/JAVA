package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_8 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Ca va être long, rentrez 20 nombres svp");

        int nombreUn = scanner.nextInt();
        for(int i = 1 ; i < 20 ; i++){
            int autreNombre = scanner.nextInt();
            if (autreNombre > nombreUn){
                nombreUn = autreNombre;

            }
        }
        System.out.println(nombreUn);






    }
}
