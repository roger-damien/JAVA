package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_9 {


    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Trouver le chiffre le plus long. Tapez 0 pour quitter");

        int nombreUn = scanner.nextInt();
        for(int i = 1 ; i < 20 ; i++){
            int autreNombre = scanner.nextInt();
            if (autreNombre > nombreUn){
                nombreUn = autreNombre;
            }
            if (autreNombre == 0){
                break;
            }
        }
        System.out.println(nombreUn);






    }

}
