package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_2 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        while (true){
            System.out.println("Taper un numéro compris entre 10 et 20");
            int numero = scanner.nextInt();

            if (numero > 20){
                System.out.println("Plus petit!");
            } else if (numero < 10){
                System.out.println("Plus grand!");
            } else{
                System.out.println("Merci !");
                break;
            }

        }

    }

}
