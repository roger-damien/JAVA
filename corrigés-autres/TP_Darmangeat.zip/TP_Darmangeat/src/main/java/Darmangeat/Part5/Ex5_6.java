package Darmangeat.Part5;

import java.util.Scanner;

public class Ex5_6 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Rentrer la valeur à atteindre");
        int valeur = scanner.nextInt();
        int calcul = 0;

        int iterationEntiers = 1;
        while (calcul < valeur){
            calcul += iterationEntiers;
            iterationEntiers++;
        }
        System.out.println(calcul);

    }
}
