package Darmangeat.Part3;

import java.util.Scanner;

public class Ex3_5 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrer deux nombres");
        double nombreUn = scanner.nextDouble();
        double nombreDeux = scanner.nextDouble();


        if (nombreUn == 0 || nombreDeux == 0){
            System.out.println("Le résultat est 0");
        } else{
            if ((nombreUn > 0 && nombreDeux > 0) || (nombreUn < 0 && nombreDeux < 0)){
                System.out.println("Le produit de ces deux nombres est positif");
            } else {
                System.out.println("Le produit de ces deux nombres est négatif");
            }
        }



    }

}
