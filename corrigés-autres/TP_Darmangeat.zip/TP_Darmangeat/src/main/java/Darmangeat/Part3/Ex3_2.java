package Darmangeat.Part3;

import java.util.Scanner;

public class Ex3_2 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        System.out.println("Merci d'entrer deux chiffres :");
        double chiffreUn = scanner.nextDouble();
        double chiffreDeux = scanner.nextDouble();

        if ((chiffreUn > 0 && chiffreDeux > 0) || (chiffreUn < 0 && chiffreDeux < 0)){
            System.out.println("Le produit de ces deux nombres est positif");
        } else {
            System.out.println("Le produit de ces deux nombres est négatif");
        }

    }

}
