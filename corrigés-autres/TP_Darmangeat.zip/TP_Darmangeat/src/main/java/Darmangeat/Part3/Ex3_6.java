package Darmangeat.Part3;

import java.util.Scanner;

public class Ex3_6 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        System.out.println("Quel est ton age petit enfant?");
        int age = scanner.nextInt();


        if (age < 6){
            System.out.println("Tu n'es pas dans la grille");
        } else if (age <= 7){
            System.out.println("Tu es un Poussin");
        } else if (age <=9){
            System.out.println("Tu es une Pupille");
        } else if (age <= 11){
            System.out.println("Tu es un Minime");
        } else{
            System.out.println("Tu es un cadet");
        }

        // Plusieurs algorithmes différents peuvent mener à ce résultat

    }

}
