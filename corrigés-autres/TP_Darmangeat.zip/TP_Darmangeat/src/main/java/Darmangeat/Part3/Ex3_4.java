package Darmangeat.Part3;

import java.util.Scanner;

public class Ex3_4 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        System.out.println("Entrer un chiffre");
        double chiffre = scanner.nextDouble();

        if (chiffre < 0){
            System.out.println(chiffre + " est un nombre négatif");
        } else if (chiffre > 0){
            System.out.println(chiffre + " est un nombre positif");
        } else {
            System.out.println("0 est une exception");
        }

    }
}
