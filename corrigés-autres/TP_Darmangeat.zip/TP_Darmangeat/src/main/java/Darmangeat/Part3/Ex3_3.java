package Darmangeat.Part3;

import java.util.Scanner;

public class Ex3_3 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("Entrer 3 noms");
        String nomUn = scanner.nextLine();
        String nomDeux = scanner.nextLine();
        String nomTrois = scanner.nextLine();

        if ( nomUn.compareToIgnoreCase(nomDeux) < 0 && nomDeux.compareToIgnoreCase(nomTrois) < 0){
            System.out.println("Ces noms sont classés alphabétiquement");
        } else{
            System.out.println("Ces noms ne sont pas classés");
        }


    }

}
