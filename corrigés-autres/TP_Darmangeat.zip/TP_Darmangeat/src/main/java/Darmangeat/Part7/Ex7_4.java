package Darmangeat.Part7;

import java.util.Arrays;
import java.util.Scanner;

public class Ex7_4 {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        int[] tableau = {12,8,4,45,64,9,2};

        System.out.println(Arrays.toString(tableau));

        System.out.println("Quel indice voulez-vous supprimer? (entre 0 et 6)");

        int supprimerIndice = scanner.nextInt();

        int[] nouveauTableau = new int[tableau.length-1];

        for (int i = 0 ; i <= nouveauTableau.length-1 ; i++){

            if ((i >= supprimerIndice)){
                nouveauTableau[i] = tableau[i+1];
            } else {
                nouveauTableau[i] = tableau[i];
            }
        }

        System.out.println(Arrays.toString(nouveauTableau));



    }
}
