package Darmangeat.Part7;

import java.util.Arrays;
import java.util.Scanner;

public class Ex7_3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("entrer les 5 valeurs du tableau");

        Integer[] tableau = new Integer[5];
        for (int i = tableau.length-1; i >= 0; i--) {
            tableau[i] = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.println(Arrays.toString(tableau));


    }

}
