package Darmangeat.Part7;

import java.util.Arrays;

public class Ex7_6 {

    public static void main(String[] args) {

        int[] tableauUn = {1,2,3,4,5,6,7,8,9,10};
        int[] tableauDeux = {1,2,3,4,5,6,7,8,9,10};

        int[] tableauTrois = new int[20];

        int indiceTabUn = 0;
        int indiceTabDeux = 0;
        for(int i = 0 ; i <= tableauTrois.length-1 ; i += 2){
            tableauTrois[i] = tableauUn[indiceTabUn];
            tableauTrois[i+1] = tableauDeux[indiceTabDeux];
            indiceTabUn++;
            indiceTabDeux++;

        }
        System.out.println(Arrays.toString(tableauTrois));







    }
}
