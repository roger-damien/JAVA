package Darmangeat.Part7;

import javax.security.sasl.SaslClient;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.Scanner;

public class Ex7_2 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("entrer les 5 valeurs du tableau");

        Integer[] tableau = new Integer[5];
        for (int i = 0; i <= tableau.length - 1; i++) {
            tableau[i] = scanner.nextInt();
            scanner.nextLine();
        }


        Arrays.sort(tableau, Comparator.reverseOrder());
        System.out.println(Arrays.toString(tableau));

    }
}
