package Darmangeat.Part7;

import java.util.Scanner;

public class Ex7_5 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        String[] dictionnaire = {"mot0", "mot1", "mot2", "mot3", "mot4", "mot5", "mot6", "mot7", "mot8", "mot9", "mot10"};

        System.out.println("Quel mot voulez-vous trouver?");

        String motATrouver = scanner.nextLine();
        boolean found = false;
        for (int i = 0 ; i<= dictionnaire.length-1 ; i++){
            if (motATrouver.equals(dictionnaire[i])){
                System.out.println("mot trouvé à l'indice " + i);
                found = true;
                break;
            }

        }
        if (!found){
            System.out.println("Mot inexistant dans le dictionnaire");
        }

    }

}
