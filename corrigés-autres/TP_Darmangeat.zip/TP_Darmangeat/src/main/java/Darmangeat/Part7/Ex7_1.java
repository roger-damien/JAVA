package Darmangeat.Part7;

import java.util.Arrays;
import java.util.Scanner;

public class Ex7_1 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("entrer les 5 valeurs du tableau");

        int[] tableau = new int[5];
        for (int i = 0 ; i <= tableau.length-1 ; i++){
            tableau[i] = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.println(Arrays.toString(tableau));

        int pointDeDepart = tableau[0];
        boolean consecutif = true;


        for(int i = 0 ; i <= tableau.length-1 ; i++){

            if (pointDeDepart != tableau[i])
            {
                consecutif = false;
                break;
            }
            pointDeDepart++;
        }
        if (consecutif){
            System.out.println("le tableau est consécutif");
        } else {
            System.out.println("Le tableau n'est pas consécutif");
        }
    }


}
