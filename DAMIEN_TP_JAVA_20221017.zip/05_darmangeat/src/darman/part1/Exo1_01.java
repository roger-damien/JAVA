package darman.part1;

public class Exo1_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 1;
		int b = a + 3;
		a = 3;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b);

	}

}
