package darman.part1;

public class Exo1_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 5;
		int b = a + 4;
		a += 1;
		b = a - 4;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b);

	}
}