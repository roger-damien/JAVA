package darman.part1;

public class Exo1_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 5;
		int b = 3;
		int c = a + b;
		a = 2;
		c = b - a;

		System.out.println("Affiche valeur a : " + a + " et b :  " + b + " et c :  " + c);

	}
}
