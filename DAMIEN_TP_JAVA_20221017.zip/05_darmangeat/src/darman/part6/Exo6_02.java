package darman.part6;

public class Exo6_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char[] monTab = { 'a', 'e', 'i', 'o', 'u', 'y' };

		for (int i = 0; i <= 5; i++) {
			System.out.println("monTab[" + i + "] = " + monTab[i]);
		}
	}
}
