package org.example;

import java.util.ArrayList;
import java.util.List;

public class Item4 {


    public static void main(String[] args) {

        List<Integer> nombrePremierListe = new ArrayList<>();

        for (int i = 2; i <= 100; ) {
            boolean nombrePremier = true;
            for (int k = 2; k <= i; k++) {
                if ((i % k) == 0 && k != i) {
                    nombrePremier = false;
                }
            }
            if (nombrePremier) {
                nombrePremierListe.add(i);
                i++;
            } else
                i++;
        }
        System.out.println("Les nombres premiers sont :");
        System.out.println(nombrePremierListe);
    }
}