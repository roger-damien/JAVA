package org.example;

import java.util.Scanner;

public class Item1 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrez une somme en €");
        double sommeEuros = scanner.nextDouble();
        double sommeDollars = convertEurosInDollars(sommeEuros);

        System.out.println(sommeEuros + "€ = ");
        System.out.println("$" + sommeDollars);
        System.out.println("$" + convertInK(sommeDollars) + "K");
        System.out.println("$" + convertInM(sommeDollars) + "M");

    }

    private static double convertEurosInDollars(double euros) {
        return euros * 0.97;
    }

    private static double convertInK(double money) {
        return money / 1000;
    }

    private static double convertInM(double money) {
        return money / 1000000;
    }
}