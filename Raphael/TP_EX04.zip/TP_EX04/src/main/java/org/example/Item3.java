package org.example;

import java.util.Scanner;

public class Item3 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Une équation du second degré à la forme " +
                "\n ax² + bx + c = 0\n");

        System.out.println("Entrez a != 0");
        double a = enterA();

        System.out.println("Entrez b");
        double b = scanner.nextDouble();

        System.out.println("Entrez c");
        double c = scanner.nextDouble();

        double discriminant = calculerDiscriminant(a, b, c);
        System.out.println(discriminant);

        calculAndDisplayResult(discriminant, a, b, c);
    }

    private static boolean isDifferentThatZero(double value) {
        return value != 0;
    }

    private static double enterA() {
        while (true) {
            double a = scanner.nextDouble();
            if (isDifferentThatZero(a)) {
                return a;
            }
            scanner.nextLine();
            System.out.println("a doit être différent de 0, recommencez.");
        }
    }

    private static double calculerDiscriminant(double a, double b, double c) {
        return (b * b) - (4 * a * c);
    }

    private static void calculAndDisplayResult(double discriminant, double a, double b, double c) {

        if (discriminantInferieurZero(discriminant)) {
            System.out.println("Il n'y a pas de solution");
        } else if (discriminantEgalZero(discriminant)) {
            System.out.println("x = " + calculSolutionSiEgalZero(a, b));
        } else {
            System.out.println("x1 = " + firstSolutionQuandSuperieurZero(discriminant, a, b));
            System.out.println("x2 = " + secondSolutionQuandSuperieurZero(discriminant, a, b));
        }
    }

    private static boolean discriminantInferieurZero(double discriminant) {
        return discriminant < 0;
    }

    private static boolean discriminantEgalZero(double discriminant) {
        return discriminant == 0;
    }

    private static double calculSolutionSiEgalZero(double a, double b) {
        return -b / (2 * a);
    }

    private static double firstSolutionQuandSuperieurZero(double discriminant, double a, double b) {
        return (-b - Math.sqrt(discriminant)) / (2 * a);
    }

    private static double secondSolutionQuandSuperieurZero(double discriminant, double a, double b) {
        return (-b + Math.sqrt(discriminant)) / (2 * a);
    }
}
