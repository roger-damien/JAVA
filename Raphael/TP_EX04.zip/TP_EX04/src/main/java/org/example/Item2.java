package org.example;

import java.util.Scanner;

public class Item2 {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Entrez 2 valeurs à calculer");
        int valeurUne = scanner.nextInt();
        int valeurDeux = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Choisir l'opération (+ ou - ou * ou /)");
        char operande = checkOperand();

        makeCalcul(valeurUne, valeurDeux, operande);
    }

    private static boolean validOperande(char operande) {
        return operande == '+' || operande == '-' || operande == '*' || operande == '/';
    }

    private static char checkOperand() {
        char operande = 'N';
        while (true) {
            operande = scanner.nextLine().charAt(0);
            if (validOperande(operande)) {
                break;
            }
            System.out.println("Tapez un opérand valide : ");
        }
        return operande;
    }

    private static void makeCalcul(double valeurUne, double valeurDeux, char operande) {
        switch (operande) {
            case '+':
                System.out.println(valeurUne + " " + operande + " " + valeurDeux + " = " + valeurUne + valeurDeux);
                break;
            case '-':
                System.out.println(valeurUne + " " + operande + " " + valeurDeux + " = " + (valeurUne - valeurDeux));
                break;
            case '*':
                System.out.println(valeurUne + " " + operande + " " + valeurDeux + " = " + (valeurUne * valeurDeux));

                break;
            case '/':
                if (valeurDeux != 0) {
                    System.out.println(valeurUne + " " + operande + " " + valeurDeux + " = " + (valeurUne / valeurDeux));
                } else {
                    System.out.println("On ne peut pas diviser par 0");
                }
                break;
        }
    }
}
